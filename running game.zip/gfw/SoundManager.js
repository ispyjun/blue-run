function SoundSystem()
{
	this.isLoadComplete = false;
	this.nowResourceLoadedCount =0;
	this.intAllResourceCount = 0;
	this.volume = 1;
	this.arrSounds = new Array();
	this.backgroundMusic = undefined;
	return this;
}

SoundSystem.prototype.AddSound = function(filename, resourceCount)
{
	var SOUND_RESOURCE_MAX = 8;
	if(resourceCount ==  undefined)
	resourceCount = SOUND_RESOURCE_MAX;
	
	for(var i=0; i<resourceCount; i++)
	{
		var soundMusic = new Audio();
		soundMusic.src = filename;
		soundMusic.volume =this.volume;
		soundMusic.isPlayed = false;
		soundMusic.addEventListener("canplaythrough", onLoadSoundComplete, false);
		soundMusic.addEventListener("ended", function()
		{
			if(window.chrome)this.load();
			this.pause();
		}, false);
		
		document.body.appendChild(soundMusic);
		
		this.arrSounds.push({name: filename, sound: soundMusic, isPlayed: false});
		
		this.intAllResourceCount++;
		}
	}
	
SoundSystem.prototype.PlaySound = function(filename)
{
	for(var i=0;i<this.arrSounds.length;i++)
	{
		if(this.arrSounds[i].name == filename)
		{
			if(this.arrSounds[i].sound.ended==true|| this.arrSounds[i].sound.isPlayed == false)
			{
				if(this.arrSounds[i].sound.paused)
				{
					this.arrSounds[i].sound.volume=this.volume;
					this.arrSounds[i].sound.play();
					this.arrSounds[i].isPlayed = true;
					break;
				}
			}
		}
	}
}

SoundSystem.prototype.PlayBackgroundMusic = function(filename)
{
	if(this.backgroundMusic)
	{
		this.backgroundMusic.sound.pause();
		this.backgroundMusic.isPlayed = false;
		this.backgroundMusic = undefined;
	}
	
	for(var i=0; i<this.arrSounds.length; i++)
	{
		if(this.arrSounds[i].name==filename)
		{
			var backgroundMusic = this.arrSounds[i];
			backgroundMusic.sound.pause();
			if(window.chrome) backgroundMusic.sound.load();
			backgroundMusic.sound.loop = true;
			backgroundMusic.isPlayed = true;
			  var playPromise = backgroundMusic.sound.play();

  if (playPromise !== undefined) {
    playPromise.then(_ => {
      backgroundMusic.sound.play();
    })
    .catch(error => {
      // Auto-play was prevented
      // Show paused UI.
    });
  }
			
			this.backgroundMusic = backgroundMusic;
		}
	}
}

SoundSystem.prototype.SetVolume=function(volume)
{
	this.volume = volume;
	
	for(var i=0;i<this.arrSounds.length;i++)
	{
		this.arrSounds[i].sound.volume=this.volume;
	}
}

var soundSystem = new SoundSystem();

function onLoadSoundComplete()
{
	soundSystem.nowResourceLodedCount++;
	
	if(soundSystem.nowResourceLoadedCount <= soundSystem.intAllResourceCount)
	{
		soundSystem.isLoadComplete = true;
	}
}
