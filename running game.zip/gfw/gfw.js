function onGameInit()
{
	document.title = "Running Game";
	
	GAME_FPS = 30;
	debugSystem.debugMode = true;
	
	resourcePreLoader.AddImage("img/title.png");
	resourcePreLoader.AddImage("img/start_on.png");
	resourcePreLoader.AddImage("img/start_off.png");
	resourcePreLoader.AddImage("img/howto_off.png");
	resourcePreLoader.AddImage("img/howto_on.png");
	
	resourcePreLoader.AddImage("img/game_background00.png");
	resourcePreLoader.AddImage("img/game_background03.png");
	resourcePreLoader.AddImage("img/howto.png");
	resourcePreLoader.AddImage("img/gameover.png");
	resourcePreLoader.AddImage("img/gameclear.png");
	
	resourcePreLoader.AddImage("img/foot.png");
	resourcePreLoader.AddImage("img/house.png");
	resourcePreLoader.AddImage("img/rock.png");
	resourcePreLoader.AddImage("img/rock2.png");
	resourcePreLoader.AddImage("img/char.png");
	resourcePreLoader.AddImage("img/char2.png");
	resourcePreLoader.AddImage("img/coin.png");
	soundSystem.AddSound("The_Fur_Purrrade.mp3",1);
	
	new gfwSocket("http://127.0.0.1:9892");
	
	after_loading_state = new TitleState();
	setInterval(gameLoop, 1000/GAME_FPS);
	
	function onGameDestory()
	{
		if(gfwSocket)
		gfwSocket.Disconnect();
	}
}

window.addEventListener("load", onGameInit, false);
