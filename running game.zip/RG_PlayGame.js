var playTime = 0;
function PlayGameState()
{
	this.background = new PGBackground();
	this.playground = new PGPlayground();
	this.player = new PGPlayer();
	this.score = 0;
	this.totalScore = 0;
	this.isGameOver = false;
	playGameState = this;
	
	this.timer = new Timer();
}

PlayGameState.prototype.Init = function()
{
	
}

PlayGameState.prototype.Notification = function(msg)
{
	switch(msg)
	{
		case"COLLISION_ROCK":
		this.isGameOver = true;
		break;
		
		case"COLLISION_HOUSE":
		this.isGameClear = true;
		break;
		
		case"PLAYER_GET_COIN":
		this.score +=10;
		break;
	};
}
PlayGameState.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	this.background.RenderLayerBack();
	
	this.playground.Render();
	this.player.Render();
	
	Context.fillStyle = "#000000";
	Context.font = '35px Arial';
	Context.textBaseline = "top";
	Context.fillText("METER :" + playTime * 2,700,5);
	
	if(this.isGameOver)
	{
		Context.fillStyle = "#000000";
		Context.font = '45px Arial';
		Context.fillText("total score :" + this.score + playTime * 2,360,280);
		Context.drawImage(resourcePreLoader.GetImage("img/gameover.png"),0,0);
	}
	if(this.isGameClear)
	{
		Context.fillStyle = "#000000";
		Context.font = '45px Arial';
		Context.fillText("total score :" + this.score + playTime * 2,360,280);
		Context.drawImage(resourcePreLoader.GetImage("img/gameclear.png"),0,0);
	}
}

PlayGameState.prototype.Update = function()
{
	if(this.isGameOver)
	{
		if(inputSystem.isKeyDown(13))
		{
			ChangeGameState(new TitleState());
		}
		else if(inputSystem.isKeyDown(82) || inputSystem.isKeyDown(114))
		{
			ChangeGameState(new PlayGameState());
		}
		return;
	}
	if(this.isGameClear)
	{
		if(inputSystem.isKeyDown(13))
		{
			ChangeGameState(new TitleState());
		}
		else if(inputSystem.isKeyDown(82) || inputSystem.isKeyDown(114))
		{
			ChangeGameState(new PlayGameState());
		}
		return;
	}
	this.background.Update();
	this.playground.Update();
	this.player.Update();
	this.playground.CheckCollision(this.player.collisionBox);
	playTime = Math.ceil(this.timer.nowFrame / 100) / 10;
}

PlayGameState.prototype.Restart = function()
{
	this.background.Init();
	this.playground.Init();
	this.player.Init();
	
	this.score = 0;
	this.isGameOver = false;
}
