function ItemCoin()
{
	this.sprCoin = new SpriteAnimation(
		resourcePreLoader.GetImage("img/coin.png"),32,32,1,1);
	
	this.x=0;
	this.y=0;
	this.type= "item";
	this.isGet= false;
	this.Invalid();
}

ItemCoin.prototype.Render = function()
{
	if(this.isGet)
	return;
	
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	this.sprCoin.Render(Context);
}

ItemCoin.prototype.Update = function()
{
	this.sprCoin.Update();
}

ItemCoin.prototype.SetPosition = function(x,y)
{
	this.sprCoin.SetPosition(x,y);
	this.Invalid();
}

ItemCoin.prototype.Translate = function(x,y)
{
	this.sprCoin.Translate(x,y);
	this.Invalid();
}

ItemCoin.prototype.Invalid = function()
{
	this.x = this.sprCoin.x;
	this.y = this.sprCoin.y;
	this.collisionBox = {left: this.sprCoin.x, top: this.sprCoin.y , right: this.sprCoin.x + 32, bottom: this.sprCoin.x + 32};
	
}

ItemCoin.prototype.CheckCollision = function(player)
{
	//if(this.isGet)
		//return;
	
	if(this.collisionBox.left<player.right || this.collisionBox.right>player.left || this.collisionBox.bottom > player.top || this.collisionBox.top < player.bottom)
			{
				debugSystem.Log("LOG","아이템 습득");
				playGameState.Notification("PLAYER_GET_COIN");
				this.isGet = true;
			}
}
