function PGPlayground()
{
	var j=0;
	
	this.imgBox = resourcePreLoader.GetImage("img/foot.png");
	this.imgRock = resourcePreLoader.GetImage("img/rock.png");
	this.intBoxY = 600-117;
	this.intRockY = 600-240;
	
	this.arrObjects = new Array();
	
	for(var i=0; i<100; i++)
	{
		var box = new GraphicObject(this.imgBox);
		box.SetPosition(120*i,this.intBoxY);
		this.arrObjects.push(box);
		j++;
		if(j%3 ==0 || j%7==0)
		{
			var rock = new GraphicObject(this.imgRock);
			rock.SetPosition(120*j,this.intBoxY);
			this.arrObjects.push(rock);
		}
	}
}

PGPlayground.prototype.AddObject = function(type)
{
	var obj;
	if(type == "box")
	{
		obj = new GraphicObject(this.imgBox);
		obj.SetPosition(0,this.intBoxY);
		obj.type ="box";
		if(this.lastObj)
			this.GotoLastPosition(obj);
	}
	else if(type == "rock")
	{
		obj = new SpriteAnimation(this.imgRock,240,120,1,1);
		obj.SetPosition(0,this.intRockY );
		obj.type="rock";
		if(this.lastObj)
			this.GotoLastPosition(obj);
	}
	
	this.arrObjects.push(obj);
	this.lastObj = obj;
}

PGPlayground.prototype.CheckCollision = function(player)
{
	for(var i=0; i<this.arrObjects.length; i++)
	{
		var obj = this.arrObjects[i];
		if(obj.type == "rock")
		{
			var collisionBox = {left:this.x+50, top: this.y + 35, right:this.x+85,bottom:this.y + 150};
			if(collisionBox.left<player.right && collisionBox.bottom > player.top && collisionBox.right>player.left && collisionBox.top < player.bottom)
			{
				debugSystem.Log("LOG","충돌");
			}
		}
	}
}

PGPlayground.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	for(var i=0;i<this.arrObjects.length;i++)
	{
		this.arrObjects[i].Render(Context);
	}
}

PGPlayground.prototype.Update = function()
{
	var speed=5;
	for(var i=0; i<this.arrObjects.length; i++)
	{
		var obj=this.arrObjects[i];
		obj.Translate(-speed,0);
		
		if(obj.Update)
			obj.Update();
			
		if(obj.x < -237)
		{
			this.GotoLastPosition(obj);
			this.lastObj = obj;
			obj.Translate(-speed,0);
		}
	}
	this.arrObjects.sort(function(obj1,obj2){return obj1.x - obj2.x});
}

PGPlayground.prototype.GotoLastPosition = function(obj)
{
	if(obj.type == "box")
	{
		if(this.lastObj.type == "rock")
			obj.SetPosition(this.lastObj.x +97,this.intBoxY);
		else
			obj.SetPosition(this.lastObj.x +237,this.intBoxY);
	}
	else if(obj.type == "rock")
	{
		obj.SetPosition(this.lastObj.x +237,this.intRockY);
	}
}


