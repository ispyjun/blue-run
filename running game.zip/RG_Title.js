function TitleState()
{
	this.imgBackground = resourcePreLoader.GetImage("img/title.png");
	this.flagButtonStart = false;
	this.imgButtonStartOff = resourcePreLoader.GetImage("img/start_off.png");
	this.imgButtonStartOn = resourcePreLoader.GetImage("img/start_on.png");
	
	this.flagButtonHowto = false;
	this.imgButtonHowtoOff = resourcePreLoader.GetImage("img/howto_off.png");
	this.imgButtonHowtoOn = resourcePreLoader.GetImage("img/howto_on.png");
	
	return this;
}

TitleState.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	Context.drawImage(this.imgBackground,0,0);
	
	if(this.flagButtonStart)
		Context.drawImage(this.imgButtonStartOn,400,337);
	else
		Context.drawImage(this.imgButtonStartOff,400,337);
		
	if(this.flagButtonHowto)
		Context.drawImage(this.imgButtonHowtoOn,400,400);
	else
		Context.drawImage(this.imgButtonHowtoOff,400,400);
		
}

TitleState.prototype.UpdateUI = function()
{
	if(inputSystem.mouseX > 400 && inputSystem.mouseY > 337 &&
	inputSystem.mouseX < 400 + 210 && inputSystem.mouseY < 337 + 60)
	{
		if(this.flagButtonStart == false)
		{
			this.flagButtonStart = true;
		}
	}
	else
	{
		this.flagButtonStart = false;
	}
	
	if(inputSystem.mouseX > 400 && inputSystem.mouseY > 400 &&
	inputSystem.mouseX < 400 + 210 && inputSystem.mouseY < 400 + 70)
	{
		if(this.flagButtonHowto == false)
		{
			this.flagButtonHowto = true;
		}
	}
	else
	{
		this.flagButtonHowto = false;
	}
}

TitleState.prototype.Update = function()
{
	this.UpdateUI();
}

TitleState.prototype.Init = function()
{
	soundSystem.PlayBackgroundMusic("The_Fur_Purrrade.mp3");
}

TitleState.prototype.onMouseDown = function()
{
	if(this.flagButtonStart)
	ChangeGameState(new PlayGameState());
	if(this.flagButtonHowto)
	ChangeGameState(new HowtoState());
}