function PGBackground()
{
	this.imgBackground00 = resourcePreLoader.GetImage("img/game_background00.png");
	this.imgBackground03 = resourcePreLoader.GetImage("img/game_background03.png");
	
	this.Init();
}

PGBackground.prototype.Init = function()
{
	this.pos01 = 400;
	this.pos02 = 0;
	this.pos03 = 0;
	
	this.speed01 = 1;
	this.speed02 = 2;
	this.speed03 = 3;
}

PGBackground.prototype.Update = function()
{
	this.pos01 -= this.speed01;
	if(this.pos01 < -900)
	{
		this.pos01 = 400;
	}
	this.pos02 -= this.speed02;
	if(this.pos02 < -1024)
	{
		this.pos02 += 1024;
	}
	this.pos03 -= this.speed03;
	if(this.pos03 < -261)
	{
		this.pos03 += 261;
	}
}

PGBackground.prototype.RenderLayerFront

PGBackground.prototype.RenderLayerFront = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
}

PGBackground.prototype.RenderLayerBack = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	Context.drawImage(this.imgBackground00,0,0);
	for(var i=0;i<2;i++){
	Context.drawImage(this.imgBackground03,this.pos02 * i ,0);
	}
	
}
