function WaitMultiPlayGameState()
{
	gfwSocket.On("start_game", function()
	{
		ChangeState(new MultiPlayGameState());
	});
}

WaitMultiPlayGameState.prototype.Init = function()
{
	gfwSocket.Emit("want_game");
}

WaitMultiPlayGameState.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	Context.fillStyle = "#000000";
	Context.font = '35px Arial';
	Context.textBaseline = "top";
	Context.fillText("SCORE :" + this.score,5,5);
}

WaitMultiPlayGameState.prototype.Update = function()
{
	
}
