function MGRivalPlayer()
{
	this.sprPlayer = new SpriteAnimation(resourcePreLoader.GetImage("img/char.png"),125,140,4,4);
	this.y = 354;
	this.isHighJumping = false;
	this.isLowJumping = false;
	this.sprPlayer.SetPosition(30,this.y);
	
}
	
MGRivalPlayer.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	this.sprPlayer.Render(Context);
}

MGRivalPlayer.prototype.Update = function()
{
	this.sprPlayer.Update();
	
	if(this.isHighJumping == true || this.isLowJumping == true)
	{
		this.y += this.jumpPower;
		this.jumpPower += 1.5;
		if(this.y>=354)
		{
			this.y = 354;
			this.isHighJumping = false;
			this.isLowJumping = false;
		}
		this.sprPlayer.SetPosition(30,this.y);
	}
}
MGRivalPlayer.prototype.Jump = function()
{
	if(this.isHighJumping == false && this.isLowJumping == false)
	{
		if(inputSystem.isKeyDown(120) || inputSystem.isKeyDown(88))
		{
			this.isHighJumping = true;
			this.jumpPower = -22;
		}
		else if(inputSystem.isKeyDown(122) || inputSystem.isKeyDown(90))
		{
			this.isLowJumping = true;
			this.jumpPower = -15;
		}
	}
}
