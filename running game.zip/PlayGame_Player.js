function PGPlayer()
{
	this.sprPlayer = new SpriteAnimation(resourcePreLoader.GetImage("img/char2.png"),125,140,4,4);
	this.Init();
}
	
PGPlayer.prototype.Init = function()
{
		this.x = 50;
		this.y = 354;
		this.isHighJumping = false;
		this.isLowJumping = false;
		this.jumpPower = 0;
		this.collisionBox = {left:this.x, top: this.y , right:this.x+125,bottom:this.y + 140};
		this.Invalid();
}

PGPlayer.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	this.sprPlayer.Render(Context);
}

PGPlayer.prototype.Update = function()
{
	this.sprPlayer.Update();
	if(this.isHighJumping == false && this.isLowJumping == false)
	{
		if(inputSystem.isKeyDown(120) || inputSystem.isKeyDown(88))
		{
			this.isHighJumping = true;
			this.jumpPower = -22;
		}
		else if(inputSystem.isKeyDown(122) || inputSystem.isKeyDown(90))
		{
			this.isLowJumping = true;
			this.jumpPower = -15;
		}
	}
	
	else
	{
		this.y += this.jumpPower;
		this.jumpPower += 1.5;
		if(this.y>=354)
		{
			this.y = 354;
			this.isHighJumping = false;
			this.isLowJumping = false;
		}
		this.Invalid();
	}
}

PGPlayer.prototype.Invalid = function()
{
	this.sprPlayer.SetPosition(this.x,this.y);
	this.collisionBox = {left:this.x , top: this.y , right:this.x+60, bottom:this.y + 90};
}
