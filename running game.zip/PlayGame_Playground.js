function PGPlayground()
{
	this.imgBox = resourcePreLoader.GetImage("img/foot.png");
	this.imgRock = resourcePreLoader.GetImage("img/rock.png");
	this.imgRock2 = resourcePreLoader.GetImage("img/rock2.png");
	this.imgHouse = resourcePreLoader.GetImage("img/house.png");
	this.intBoxY = 600-117;
	this.intHouseY = 600-117-370;
	this.intRockY = 600 - 117 - 160;
	this.intRockY2 = 600 - 117 -70;
	
	this.Init();
}

PGPlayground.prototype.Init = function(type)
{	
	this.lastObj = null;
	this.arrObjects = new Array();
	
	for(var i=0; i<100; i++)
	{
		var box = new GraphicObject(this.imgBox);
		box.SetPosition(120*i,this.intBoxY);
		
		this.arrObjects.push(box);
	}
	
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("Rock2");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("box");
	this.AddObject("House");
	
}

PGPlayground.prototype.AddObject = function(type)
{
	var obj;
	if(type == "box")
	{
		obj = new GraphicObject(this.imgBox);
		obj.SetPosition(0, this.intBoxY);
		obj.type = "box";
		if(this.lastObj)
		this.GotoLastPosition(obj);
	}
	else if(type == "House")
	{
		obj = new SpriteAnimation(this.imgHouse,400,370,1,1);
		obj.SetPosition(0, this.intHouseY);
		obj.type = "House";
		if(this.lastObj)
		this.GotoLastPosition(obj);
	}
	else if(type == "Rock")
	{
		obj = new SpriteAnimation(this.imgRock,120,160,1,1);
		obj.SetPosition(0, this.intRockY);
		obj.type = "Rock";
		if(this.lastObj)
		this.GotoLastPosition(obj);
	}
	else if(type == "Rock2")
	{
		obj = new SpriteAnimation(this.imgRock2,70,70,1,1);
		obj.SetPosition(0, this.intRockY2);
		obj.type = "Rock2";
		if(this.lastObj)
		this.GotoLastPosition(obj);
	}
	this.arrObjects.push(obj);
	this.lastObj = obj;
}

PGPlayground.prototype.AddItem = function(type)
{
	var obj;
	if(type == "coin")
	{
		obj = new ItemCoin();
		if(this.lastObj)
		this.GotoLastPosition(obj);
	}
	this.arrObjects.push(obj);
}

PGPlayground.prototype.CheckCollision = function(player)
{
	for(var i=0; i<this.arrObjects.length; i++)
	{
		var obj = this.arrObjects[i];
		if(obj.type == "Rock")
		{
			var collisionBox = {left:obj.x + 15, top: obj.y - 10 , right:obj.x + 55,bottom:obj.y + 140};
			if( collisionBox.left<player.right && collisionBox.right>player.left &&collisionBox.bottom > player.top && collisionBox.top < player.bottom)
			{
				playGameState.Notification("COLLISION_ROCK");
			}
			if(obj.type == "item")
			{
				obj.CheckCollision(player);
			}
		}
		if(obj.type == "Rock2")
		{
			var collisionBox = {left:obj.x + 15, top: obj.y - 10 , right:obj.x + 55,bottom:obj.y + 55};
			if( collisionBox.left<player.right && collisionBox.right>player.left &&collisionBox.bottom > player.top && collisionBox.top < player.bottom)
			{
				playGameState.Notification("COLLISION_ROCK");
			}
			if(obj.type == "item")
			{
				obj.CheckCollision(player);
			}
		}
		if(obj.type == "House")
		{
			var collisionBox = {left:obj.x + 15, top: obj.y - 10 , right:obj.x + 55,bottom:obj.y + 55};
			if( collisionBox.left<player.right)
			{
				playGameState.Notification("COLLISION_HOUSE");
			}
		}
	}
}


PGPlayground.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	for(var i=0;i<this.arrObjects.length;i++)
	{
		this.arrObjects[i].Render(Context);
	}
}

PGPlayground.prototype.Update = function()
{
	var speed=15;
	for(var i=0;i<this.arrObjects.length;i++)
	{
		var obj = this.arrObjects[i];
			obj.Translate(-speed,0);
		if(obj.Update)
		obj.Update();
		
		if(obj.x < -120)
		{
			this.GotoLastPosition(obj);
			obj.Translate(-speed,0);
			if(obj.type != "item")
				this.lastObj = obj;
			
		}
	}
	this.arrObjects.sort(function(obj1,obj2){return obj1.x - obj2.x});
}

PGPlayground.prototype.GotoLastPosition = function(obj)
{
	if(obj.type == "box")
	{
		if(this.lastObj.type == "Rock")
			obj.SetPosition(this.lastObj.x + 97, this.intBoxY);
		else if(this.lastObj.type == "Rock2")
			obj.SetPosition(this.lastObj.x + 97, this.intBoxY);
		else
			obj.SetPosition(this.lastObj.x + 120 - 26, this.intBoxY);
	}
	else if(obj.type == "Rock")
	{
		obj.SetPosition(this.lastObj.x + 120, this.intRockY);	
	}
	else if(obj.type == "Rock2")
	{
		obj.SetPosition(this.lastObj.x + 70, this.intRockY2);	
	}
	else if(obj.type == "House")
	{
		obj.SetPosition(this.lastObj.x + 120, this.intHouseY + 90);	
	}
	else if(obj.type == "item")
	{
		obj.isGet = false;
		if(this.lastObj.type =="box")
			obj.SetPosition(this.lastObj.x + 120,this.intBoxY - 40);
		else if(this.lastObj.type == "Rock")
			obj.SetPosition(this.lastObj.x + 20,this.intRockY - 40);		
		else if(this.lastObj.type == "Rock2")
			obj.SetPosition(this.lastObj.x + 20,this.intRockY - 40);	
	}
}


