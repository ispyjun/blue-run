function HowtoState()
{
	this.imgHowto = resourcePreLoader.GetImage("img/howto.png");
	
	
}

HowtoState.prototype.Render = function()
{
	var theCanvas = document.getElementById("GameCanvas");
	var Context = theCanvas.getContext("2d");
	
	Context.drawImage(this.imgHowto,0,0);
		
}

HowtoState.prototype.Init = function()
{
	
}

HowtoState.prototype.Update = function()
{
	if(inputSystem.isKeyDown(13))
		{
			ChangeGameState(new TitleState());
		}
		return;
}